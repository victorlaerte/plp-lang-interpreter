package li2.plp.expressions2.memory;

import li2.plp.expressions1.util.Tipo;


public interface AmbienteCompilacao extends Ambiente<Tipo> {

}
