package expressao1.main;

import java.io.File;
import java.io.FileInputStream;

import expressao1.javaCC.Parser;

public class Main {
	
	public static void main(String[] args) {
		try {
			FileInputStream fis = new FileInputStream (new File("file.txt"));
			Parser.parse(fis);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
