package expressao1.programa.expressao.expBinaria;

import expressao1.programa.expressao.Expressao;

public class ExpConcat extends ExpBinaria {

	public ExpConcat(Expressao expressaoEsq, Expressao expressaoDir, String operador) {
		super(expressaoEsq, expressaoDir, operador);
	}

}
