package expressao1.programa;

import expressao1.programa.expressao.Expressao;


public class Programa {

	Expressao expressao;
	
	public Programa (Expressao expressao) {
		this.expressao = expressao;
	}
	
	@Override
	public String toString() {
		return this.expressao.toString();
	}
	
}
