package expressao1.programa.expressao.expUnaria;

import expressao1.programa.expressao.Expressao;

public class ExpLength extends ExpUnaria {

	public ExpLength(String operador, Expressao expressao1) {
		super(operador, expressao1);
	}

}
