package expressao1.programa.expressao.expUnaria;

import expressao1.programa.expressao.Expressao;

public class ExpNot extends ExpUnaria {

	public ExpNot(String operador, Expressao expressao1) {
		super(operador, expressao1);
	}

}
