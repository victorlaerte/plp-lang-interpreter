package expressao1.programa.expressao.expUnaria;

import expressao1.programa.expressao.Expressao;

public abstract class ExpUnaria implements Expressao {
	Expressao exp;
	String operador;
	
	public ExpUnaria(String operador, Expressao expressao1) {
		this.operador = operador;
		this.exp = expressao1;
	}
	
	@Override
	public String toString() {
		return this.operador + " " + exp.toString();
	}
}
