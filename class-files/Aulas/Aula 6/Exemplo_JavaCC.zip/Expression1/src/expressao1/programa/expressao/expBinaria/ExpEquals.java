package expressao1.programa.expressao.expBinaria;

import expressao1.programa.expressao.Expressao;

public class ExpEquals extends ExpBinaria {

	public ExpEquals(Expressao expressaoEsq, Expressao expressaoDir, String operador) {
		super(expressaoEsq, expressaoDir, operador);
	}

}
