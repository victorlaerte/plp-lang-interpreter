package expressao1.programa.expressao.expBinaria;

import expressao1.programa.expressao.Expressao;

public abstract class ExpBinaria implements Expressao {

	Expressao expressaoEsq;
	Expressao expressaoDir;
	String operador;
	
	public ExpBinaria(Expressao expressaoEsq, Expressao expressaoDir, String operador) {
		this.expressaoEsq = expressaoEsq;
		this.expressaoDir = expressaoDir;
		this.operador = operador;
	}
	
	@Override
	public String toString() {
		return this.expressaoEsq + " " + this.operador + " " + this.expressaoDir;
	}
	
	
	
}
