package expressao1.programa.expressao;

public interface Expressao {
	
	
}
