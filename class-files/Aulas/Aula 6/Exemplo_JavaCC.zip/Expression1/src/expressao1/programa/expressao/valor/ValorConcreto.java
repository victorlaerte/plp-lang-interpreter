package expressao1.programa.expressao.valor;

public abstract class ValorConcreto<T> implements Valor {

	T valor;
	
	@Override
	public String toString() {
		return valor.toString();
	}
	
	public ValorConcreto (T valor){
		this.valor = valor;
	}
}
