package expressao1.programa.expressao.valor;

import expressao1.programa.expressao.Expressao;

public interface Valor extends Expressao {

}
