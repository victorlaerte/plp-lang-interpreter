package expressao1.programa.expressao.valor;

public class ValorString extends ValorConcreto<String> {

	public ValorString(String valor) {
		super(valor);
	}

}
