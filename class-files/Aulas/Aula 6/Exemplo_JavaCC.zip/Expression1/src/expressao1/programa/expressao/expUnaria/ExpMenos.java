package expressao1.programa.expressao.expUnaria;

import expressao1.programa.expressao.Expressao;

public class ExpMenos extends ExpUnaria {

	public ExpMenos(String operador, Expressao expressao1) {
		super(operador, expressao1);
	}

}
