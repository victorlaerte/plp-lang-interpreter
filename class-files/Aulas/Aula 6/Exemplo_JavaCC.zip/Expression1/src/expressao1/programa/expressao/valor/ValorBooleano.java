package expressao1.programa.expressao.valor;

public class ValorBooleano extends ValorConcreto<Boolean> {

	public ValorBooleano(Boolean valor) {
		super(valor);
	}

}
