package expressao1.programa.expressao.expBinaria;

import expressao1.programa.expressao.Expressao;

public class ExpOr extends ExpBinaria {

	public ExpOr(Expressao expressaoEsq, Expressao expressaoDir, String operador) {
		super(expressaoEsq, expressaoDir, operador);
	}

}
